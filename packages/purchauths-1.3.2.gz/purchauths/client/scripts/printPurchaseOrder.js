// Restrict PO by Order Type ("Open")
var _po = mywindow.findChild("_po");

_po.setAllowedStatuses(2);