COMMENT ON SCHEMA purchauths
  IS 'xTuple Purchasing Authorisations

Copyright (c) 2013-2016 Pentuple Consulting Ltd. (New Zealand) www.pentuple.co.nz

Copyright (c) 2013-2016 by xTuple LLC.
        It is licensed to you under the Common Public Attribution License
        version 1.0, the full text of which (including xTuple-specific Exhibits)
        is available at www.xtuple.com/CPAL.  By using this software, you agree
        to be bound by its terms.';
