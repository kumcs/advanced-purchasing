// Copyright (c) 2013 Pentuple Consulting (New Zealand) www.pentuple.co.nz
// All rights Reserved.

var _usePurchAuths = toolbox.createWidget("QCheckBox", mywindow, "_usePurchAuths");
_usePurchAuths.text = qsTr("Use Purchasing Authorizations");

var _layout = toolbox.widgetGetLayout(mywindow.findChild("_printPO"));

_layout.addWidget(_usePurchAuths,0,10);

function configSave()
{
  metrics.set("UsePurchasingAuths", _usePurchAuths.checked)
}

mywindow.saving.connect(configSave);

_usePurchAuths.checked = metrics.boolean("UsePurchasingAuths");