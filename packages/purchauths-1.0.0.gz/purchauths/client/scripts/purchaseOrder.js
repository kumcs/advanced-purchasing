var _printPO = mywindow.findChild("_printPO");
var _status  = mywindow.findChild("_status");
var _mode;

function set(input)
{
  if ("mode" in input)
    _mode = input.mode;
}

function showEvent()
{ 
  if (metrics.boolean("UsePurchasingAuths"))
  {
  // Prevent printing unreleased (or closed) POs  
    if (_status.currentIndex != 1)
    {
      _status.enabled = false; 
      _printPO.checked = false;
      _printPO.enabled = false;
    }        
  }
}