COMMENT ON SCHEMA purchauths
  IS 'xTuple Purchasing Authorisations

Copyright (c) 2013 Pentuple Consulting Ltd. (New Zealand) www.pentuple.co.nz';
